# Anwar-Ul Islam Model College – Digital Portal (PWA Prototype)

**Official school information source:** https://anwarulislammodelcollege.com/

## What this is
A modern, responsive, installable Progressive Web App (PWA) frontend prototype for Anwar-Ul Islam Model College, Agege, Lagos.

- Uses the **real official logo** and published school history, vision, mission, contact details, principal, board members and facilities.
- Four role-based experiences: **Student**, **Parent**, **Teacher**, **Administrator**.
- Functional navigation, dashboards, digital ID card, results, fees UI, CBT placeholder, AI assistant placeholder, announcements, gallery (official images), calendar, messaging UI, admissions overview, etc.
- PWA-ready: web app manifest + service worker + offline fallback.
- Works on iPhone, Android, tablet and desktop.
- Demo login only – no real authentication or database yet.

## How to run
1. Serve the folder with any static file server (required for service worker and proper PWA behaviour).
   ```bash
   npx serve .
   # or
   python3 -m http.server 8080
   ```
2. Open the URL in a browser.
3. Click **Portal Login** or any role card to explore.

## Important notes
- **No invented school facts.** Missing details (exact fee amounts, full timetable, house names beyond placeholders) are clearly marked as administrator-editable.
- CBT, AI Study Assistant, real payments, secure messaging and admissions workflow are **UI + architecture ready**. They require a secure backend (Node/Supabase/Firebase etc.) and must never expose API keys on the frontend.
- Colours: Teal / Blue + Gold / Yellow + White (matching the official website).
- Excluded as requested: Islamic Centre, school bus/transport system.

## Next steps for production
1. Add authentication (e.g. Supabase Auth or Firebase Auth) with role claims.
2. Connect a real database for students, parents, results, fees, attendance.
3. Integrate a Nigerian payment provider (Paystack / Flutterwave).
4. Implement the full CBT engine and secure AI proxy.
5. Add push notifications, proper QR generation for student ID, and admin content management.
6. Host on a secure HTTPS domain and submit for app-store / PWA distribution if desired.

---
**Anwar-Ul Islam Model College**  
1, Oniwaya Road, Dopemu Agege, Lagos  
Learn • Grow • Excel
