/**
 * Anwar-Ul Islam Model College – Digital Portal (PWA Frontend Prototype)
 * Role-based SPA with realistic UI and official school data.
 */

const state = {
  user: null,
  currentView: 'landing',
  activeChild: null // for parent multi-child
};

// ---------- Helpers ----------
function $(sel, parent = document) { return parent.querySelector(sel); }
function $$(sel, parent = document) { return [...parent.querySelectorAll(sel)]; }

function toast(msg, type = 'info') {
  const container = $('#toast-container');
  const el = document.createElement('div');
  el.className = `toast px-4 py-3 rounded-lg shadow-lg text-white text-sm font-medium ${
    type === 'success' ? 'bg-teal-600' : type === 'error' ? 'bg-red-600' : 'bg-gray-800'
  }`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

function formatCurrency(n) {
  return new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 }).format(n);
}

function formatDate(d) {
  return new Date(d).toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ---------- Auth (demo) ----------
function loginAs(role) {
  state.user = { ...DEMO_USERS[role] };
  if (role === 'parent') state.activeChild = DEMO_USERS.student;
  toast(`Welcome, ${state.user.name}`, 'success');
  navigate('dashboard');
}

function logout() {
  state.user = null;
  state.activeChild = null;
  navigate('landing');
  toast('You have been logged out');
}

// ---------- Navigation ----------
function navigate(view, params = {}) {
  state.currentView = view;
  render();
  window.scrollTo(0, 0);
}

// ---------- Renderers ----------
function render() {
  const app = $('#app');
  if (!state.user) {
    if (state.currentView === 'about') app.innerHTML = renderAbout();
    else if (state.currentView === 'contact') app.innerHTML = renderContact();
    else app.innerHTML = renderLanding();
  } else {
    app.innerHTML = renderShell();
  }
  // Attach event listeners after render
  bindEvents();
}

function renderLanding() {
  return `
  <div class="page-enter">
    <!-- Header -->
    <header class="bg-school-teal text-white sticky top-0 z-50 shadow-md">
      <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <img src="${SCHOOL.logo}" alt="AIMC Logo" class="h-10 md:h-12 object-contain bg-white rounded px-1" />
          <div class="hidden sm:block">
            <div class="font-bold text-sm leading-tight">Anwar-Ul Islam</div>
            <div class="text-xs opacity-90">Model College</div>
          </div>
        </div>
        <nav class="hidden md:flex items-center gap-6 text-sm font-medium">
          <button onclick="navigate('landing')" class="hover:text-yellow-300">Home</button>
          <button onclick="navigate('about')" class="hover:text-yellow-300">About</button>
          <button onclick="navigate('contact')" class="hover:text-yellow-300">Contact</button>
        </nav>
        <button onclick="document.getElementById('login-modal').classList.remove('hidden')" 
          class="bg-school-gold hover:bg-yellow-500 text-gray-900 font-semibold px-4 py-2 rounded-lg text-sm transition">
          Portal Login
        </button>
      </div>
    </header>

    <!-- Hero -->
    <section class="relative bg-gradient-to-br from-school-teal via-teal-700 to-school-navy text-white overflow-hidden">
      <div class="absolute inset-0 opacity-10 bg-[url('https://anwarulislammodelcollege.com/wp-content/uploads/2024/05/Front-of-School.jpg')] bg-cover bg-center"></div>
      <div class="relative max-w-6xl mx-auto px-4 py-16 md:py-24 text-center">
        <img src="${SCHOOL.logo}" alt="Logo" class="h-16 md:h-20 mx-auto mb-6 bg-white/90 rounded-lg p-2 shadow-lg" />
        <h1 class="text-3xl md:text-5xl font-bold tracking-tight mb-3">Anwar-Ul Islam Model College</h1>
        <p class="text-school-gold text-lg md:text-xl font-medium mb-2">${SCHOOL.motto}</p>
        <p class="max-w-2xl mx-auto text-teal-100 text-sm md:text-base mb-8">${SCHOOL.tagline}</p>
        <div class="flex flex-wrap justify-center gap-3">
          <button onclick="document.getElementById('login-modal').classList.remove('hidden')" 
            class="bg-school-gold hover:bg-yellow-400 text-gray-900 font-bold px-6 py-3 rounded-xl shadow-lg transition">
            Access Portal
          </button>
          <button onclick="navigate('about')" 
            class="bg-white/15 hover:bg-white/25 backdrop-blur border border-white/30 px-6 py-3 rounded-xl font-semibold transition">
            About the School
          </button>
        </div>
      </div>
    </section>

    <!-- Quick stats / features -->
    <section class="max-w-6xl mx-auto px-4 -mt-8 relative z-10">
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        ${[
          { label: 'Founded', value: '1948' },
          { label: 'Location', value: 'Agege, Lagos' },
          { label: 'Type', value: 'Boys College' },
          { label: 'Focus', value: 'Islamic + Western' }
        ].map(s => `
          <div class="bg-white rounded-xl shadow-md p-4 text-center border border-gray-100">
            <div class="text-2xl font-bold text-school-teal">${s.value}</div>
            <div class="text-xs text-gray-500 mt-1">${s.label}</div>
          </div>
        `).join('')}
      </div>
    </section>

    <!-- Vision & Mission -->
    <section class="max-w-6xl mx-auto px-4 py-12 md:py-16">
      <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <div class="text-school-gold font-bold text-sm uppercase tracking-wider mb-2">Our Vision</div>
          <p class="text-gray-700 leading-relaxed">${SCHOOL.vision}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <div class="text-school-gold font-bold text-sm uppercase tracking-wider mb-2">Our Mission</div>
          <p class="text-gray-700 leading-relaxed">${SCHOOL.mission}</p>
        </div>
      </div>
    </section>

    <!-- Facilities preview -->
    <section class="bg-gray-100 py-12">
      <div class="max-w-6xl mx-auto px-4">
        <h2 class="text-2xl font-bold text-center mb-8 text-school-navy">Why Choose AIMC</h2>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          ${SCHOOL.facilities.slice(0, 6).map(f => `
            <div class="bg-white rounded-xl p-4 flex items-start gap-3 shadow-sm">
              <span class="text-school-teal text-xl">✓</span>
              <span class="text-sm text-gray-700">${f}</span>
            </div>
          `).join('')}
        </div>
        <div class="text-center mt-6">
          <button onclick="navigate('about')" class="text-school-teal font-semibold hover:underline">View all facilities & history →</button>
        </div>
      </div>
    </section>

    <!-- Role entry cards -->
    <section class="max-w-6xl mx-auto px-4 py-12 md:py-16">
      <h2 class="text-2xl font-bold text-center mb-2 text-school-navy">School Portal</h2>
      <p class="text-center text-gray-500 mb-8 text-sm">Select your role to continue (Demo login – no real credentials required)</p>
      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        ${[
          { role: 'student', title: 'Student', desc: 'Timetable, results, assignments, CBT, ID card', color: 'teal' },
          { role: 'parent', title: 'Parent', desc: 'Attendance, results, fees, messaging, calendar', color: 'blue' },
          { role: 'teacher', title: 'Teacher', desc: 'Classes, attendance, results upload, CBT', color: 'indigo' },
          { role: 'admin', title: 'Administrator', desc: 'Full school management & reports', color: 'amber' }
        ].map(r => `
          <button onclick="loginAs('${r.role}')" 
            class="card-hover bg-white rounded-2xl p-6 text-left border border-gray-100 shadow-sm hover:border-school-teal/40 group">
            <div class="w-12 h-12 rounded-xl bg-school-teal/10 text-school-teal flex items-center justify-center text-2xl mb-4 group-hover:bg-school-teal group-hover:text-white transition">
              ${r.role === 'student' ? '🎓' : r.role === 'parent' ? '👨‍👩‍👧' : r.role === 'teacher' ? '👩‍🏫' : '⚙️'}
            </div>
            <h3 class="font-bold text-lg text-gray-900">${r.title}</h3>
            <p class="text-sm text-gray-500 mt-1">${r.desc}</p>
          </button>
        `).join('')}
      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-school-navy text-white mt-auto">
      <div class="max-w-6xl mx-auto px-4 py-10">
        <div class="flex flex-col md:flex-row justify-between gap-6">
          <div>
            <img src="${SCHOOL.logo}" alt="Logo" class="h-12 bg-white rounded p-1 mb-3" />
            <p class="text-sm text-gray-300 max-w-xs">${SCHOOL.name}<br>${SCHOOL.address}</p>
          </div>
          <div class="text-sm">
            <div class="font-semibold mb-2">Contact</div>
            <p>${SCHOOL.phone}</p>
            <p>${SCHOOL.email}</p>
            <a href="${SCHOOL.website}" target="_blank" class="text-school-gold hover:underline">Official Website</a>
          </div>
          <div class="text-sm">
            <div class="font-semibold mb-2">Portal</div>
            <button onclick="navigate('about')" class="block hover:text-school-gold">About School</button>
            <button onclick="navigate('contact')" class="block hover:text-school-gold">Contact</button>
          </div>
        </div>
        <div class="border-t border-white/10 mt-8 pt-6 text-center text-xs text-gray-400">
          © ${new Date().getFullYear()} Anwar-Ul Islam Model College, Agege. Digital Portal Prototype.
        </div>
      </div>
    </footer>

    <!-- Login Modal -->
    <div id="login-modal" class="hidden fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-xl font-bold text-school-navy">Portal Login</h3>
          <button onclick="document.getElementById('login-modal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
        </div>
        <p class="text-sm text-gray-500 mb-6">This is a demonstration portal. Choose a role to explore the interface. No real credentials are required.</p>
        <div class="space-y-3">
          <button onclick="loginAs('student'); document.getElementById('login-modal').classList.add('hidden')" class="w-full py-3 rounded-xl bg-school-teal text-white font-semibold hover:bg-school-tealDark transition">Continue as Student</button>
          <button onclick="loginAs('parent'); document.getElementById('login-modal').classList.add('hidden')" class="w-full py-3 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700 transition">Continue as Parent</button>
          <button onclick="loginAs('teacher'); document.getElementById('login-modal').classList.add('hidden')" class="w-full py-3 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 transition">Continue as Teacher</button>
          <button onclick="loginAs('admin'); document.getElementById('login-modal').classList.add('hidden')" class="w-full py-3 rounded-xl bg-amber-600 text-white font-semibold hover:bg-amber-700 transition">Continue as Administrator</button>
        </div>
      </div>
    </div>
  </div>`;
}

function renderAbout() {
  return `
  <div class="page-enter min-h-screen flex flex-col">
    <header class="bg-school-teal text-white sticky top-0 z-50 shadow">
      <div class="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
        <button onclick="navigate('landing')" class="flex items-center gap-2 text-sm font-medium">
          <span>←</span> Back
        </button>
        <span class="font-semibold">About the School</span>
        <div class="w-12"></div>
      </div>
    </header>
    <main class="flex-1 max-w-4xl mx-auto px-4 py-8">
      <div class="text-center mb-8">
        <img src="${SCHOOL.logo}" alt="Logo" class="h-16 mx-auto mb-4 bg-white rounded-lg p-2 shadow" />
        <h1 class="text-2xl md:text-3xl font-bold text-school-navy">${SCHOOL.name}</h1>
        <p class="text-school-gold font-medium mt-1">${SCHOOL.motto}</p>
      </div>

      <section class="bg-white rounded-2xl p-6 shadow-sm border mb-6">
        <h2 class="text-lg font-bold text-school-teal mb-3">Our History</h2>
        <div class="prose prose-sm text-gray-700 whitespace-pre-line leading-relaxed">${SCHOOL.historyFull}</div>
      </section>

      <div class="grid md:grid-cols-2 gap-4 mb-6">
        <div class="bg-white rounded-2xl p-5 shadow-sm border">
          <h3 class="font-bold text-school-gold mb-2">Vision</h3>
          <p class="text-sm text-gray-700">${SCHOOL.vision}</p>
        </div>
        <div class="bg-white rounded-2xl p-5 shadow-sm border">
          <h3 class="font-bold text-school-gold mb-2">Mission</h3>
          <p class="text-sm text-gray-700">${SCHOOL.mission}</p>
        </div>
      </div>

      <section class="bg-white rounded-2xl p-6 shadow-sm border mb-6">
        <h2 class="text-lg font-bold text-school-teal mb-4">Board of Governors & Leadership</h2>
        <div class="space-y-2">
          ${SCHOOL.board.map(b => `
            <div class="flex justify-between items-center py-2 border-b border-gray-50 last:border-0">
              <span class="font-medium text-sm">${b.name}</span>
              <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">${b.role}</span>
            </div>
          `).join('')}
        </div>
      </section>

      <section class="bg-white rounded-2xl p-6 shadow-sm border mb-6">
        <h2 class="text-lg font-bold text-school-teal mb-4">Facilities</h2>
        <ul class="grid sm:grid-cols-2 gap-2">
          ${SCHOOL.facilities.map(f => `<li class="text-sm text-gray-700 flex gap-2"><span class="text-school-teal">•</span> ${f}</li>`).join('')}
        </ul>
      </section>

      <div class="text-center text-sm text-gray-500">
        Source: <a href="${SCHOOL.website}" target="_blank" class="text-school-teal hover:underline">Official Website</a>
      </div>
    </main>
  </div>`;
}

function renderContact() {
  return `
  <div class="page-enter min-h-screen flex flex-col">
    <header class="bg-school-teal text-white sticky top-0 z-50 shadow">
      <div class="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
        <button onclick="navigate('landing')" class="flex items-center gap-2 text-sm font-medium">← Back</button>
        <span class="font-semibold">Contact Us</span>
        <div class="w-12"></div>
      </div>
    </header>
    <main class="flex-1 max-w-lg mx-auto px-4 py-10">
      <div class="bg-white rounded-2xl p-6 shadow-sm border text-center">
        <img src="${SCHOOL.logo}" alt="Logo" class="h-14 mx-auto mb-4 bg-gray-50 rounded p-1" />
        <h1 class="text-xl font-bold text-school-navy mb-6">${SCHOOL.name}</h1>
        <div class="space-y-4 text-left text-sm">
          <div>
            <div class="text-xs text-gray-400 uppercase tracking-wide">Address</div>
            <div class="font-medium">${SCHOOL.address}</div>
          </div>
          <div>
            <div class="text-xs text-gray-400 uppercase tracking-wide">Phone</div>
            <a href="tel:${SCHOOL.phone}" class="font-medium text-school-teal">${SCHOOL.phone}</a>
          </div>
          <div>
            <div class="text-xs text-gray-400 uppercase tracking-wide">Email</div>
            <a href="mailto:${SCHOOL.email}" class="font-medium text-school-teal">${SCHOOL.email}</a>
          </div>
          <div>
            <div class="text-xs text-gray-400 uppercase tracking-wide">Website</div>
            <a href="${SCHOOL.website}" target="_blank" class="font-medium text-school-teal">${SCHOOL.website}</a>
          </div>
        </div>
      </div>
    </main>
  </div>`;
}

function renderShell() {
  const role = state.user.role;
  const navItems = getNavForRole(role);
  return `
  <div class="page-enter min-h-screen flex flex-col bg-gray-50">
    <!-- Top bar -->
    <header class="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div class="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <img src="${SCHOOL.logo}" alt="Logo" class="h-9 object-contain" />
          <div class="hidden sm:block">
            <div class="text-sm font-bold text-school-navy leading-tight">AIMC Portal</div>
            <div class="text-[10px] text-gray-400 uppercase tracking-wider role-badge">${role}</div>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <span class="text-sm font-medium text-gray-700 hidden sm:inline">${state.user.name}</span>
          <button onclick="logout()" class="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg font-medium transition">Logout</button>
        </div>
      </div>
    </header>

    <div class="flex-1 flex max-w-6xl mx-auto w-full">
      <!-- Side nav (desktop) -->
      <aside class="hidden md:block w-56 shrink-0 border-r border-gray-200 bg-white p-3 sticky top-[53px] h-[calc(100vh-53px)] overflow-y-auto">
        <nav class="space-y-1">
          ${navItems.map(item => `
            <button onclick="navigate('${item.view}')" 
              class="w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition ${
                state.currentView === item.view || (state.currentView === 'dashboard' && item.view === 'dashboard')
                  ? 'bg-school-teal/10 text-school-teal' : 'text-gray-600 hover:bg-gray-50'
              }">
              <span class="mr-2">${item.icon}</span>${item.label}
            </button>
          `).join('')}
        </nav>
      </aside>

      <!-- Main content -->
      <main class="flex-1 p-4 md:p-6 pb-24 md:pb-6 overflow-x-hidden">
        ${renderDashboardContent()}
      </main>
    </div>

    <!-- Bottom nav (mobile) -->
    <nav class="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 bottom-nav z-40">
      <div class="flex justify-around py-2">
        ${navItems.slice(0, 5).map(item => `
          <button onclick="navigate('${item.view}')" class="flex flex-col items-center px-2 py-1 ${
            state.currentView === item.view ? 'text-school-teal' : 'text-gray-400'
          }">
            <span class="text-lg">${item.icon}</span>
            <span class="text-[10px] font-medium mt-0.5">${item.short || item.label.split(' ')[0]}</span>
          </button>
        `).join('')}
      </div>
    </nav>
  </div>`;
}

function getNavForRole(role) {
  const common = [{ view: 'dashboard', label: 'Dashboard', short: 'Home', icon: '🏠' }];
  if (role === 'student') {
    return [
      ...common,
      { view: 'timetable', label: 'Timetable', icon: '📅' },
      { view: 'results', label: 'Results', icon: '📊' },
      { view: 'idcard', label: 'Student ID', short: 'ID', icon: '🪪' },
      { view: 'assignments', label: 'Assignments', icon: '📝' },
      { view: 'cbt', label: 'CBT Exams', short: 'CBT', icon: '💻' },
      { view: 'learning', label: 'Learning Centre', short: 'Learn', icon: '📚' },
      { view: 'ai', label: 'AI Assistant', short: 'AI', icon: '🤖' },
      { view: 'announcements', label: 'Announcements', short: 'News', icon: '📢' },
      { view: 'gallery', label: 'Gallery', icon: '🖼️' },
      { view: 'achievements', label: 'Achievements', short: 'Badges', icon: '🏆' }
    ];
  }
  if (role === 'parent') {
    return [
      ...common,
      { view: 'children', label: 'My Children', short: 'Kids', icon: '👨‍👩‍👧' },
      { view: 'results', label: 'Results', icon: '📊' },
      { view: 'fees', label: 'Fees & Payments', short: 'Fees', icon: '💳' },
      { view: 'attendance', label: 'Attendance', icon: '✅' },
      { view: 'announcements', label: 'Announcements', short: 'News', icon: '📢' },
      { view: 'messages', label: 'Messages', icon: '💬' },
      { view: 'calendar', label: 'Calendar', icon: '📆' }
    ];
  }
  if (role === 'teacher') {
    return [
      ...common,
      { view: 'classes', label: 'My Classes', short: 'Classes', icon: '🏫' },
      { view: 'attendance', label: 'Take Attendance', short: 'Attend', icon: '✅' },
      { view: 'results-upload', label: 'Upload Results', short: 'Results', icon: '📤' },
      { view: 'assignments', label: 'Assignments', icon: '📝' },
      { view: 'cbt-manage', label: 'Manage CBT', short: 'CBT', icon: '💻' },
      { view: 'announcements', label: 'Announcements', short: 'News', icon: '📢' }
    ];
  }
  // admin
  return [
    ...common,
    { view: 'students', label: 'Students', icon: '🎓' },
    { view: 'admissions', label: 'Admissions', icon: '📋' },
    { view: 'fees-admin', label: 'Fees', icon: '💰' },
    { view: 'results-admin', label: 'Results', icon: '📊' },
    { view: 'announcements', label: 'Announcements', short: 'News', icon: '📢' },
    { view: 'settings', label: 'School Settings', short: 'Settings', icon: '⚙️' }
  ];
}

function renderDashboardContent() {
  const view = state.currentView;
  const role = state.user.role;

  if (view === 'dashboard') return renderRoleDashboard(role);
  if (view === 'timetable') return renderTimetable();
  if (view === 'results') return renderResults();
  if (view === 'idcard') return renderIdCard();
  if (view === 'assignments') return renderAssignments();
  if (view === 'cbt') return renderCBT();
  if (view === 'learning') return renderLearning();
  if (view === 'ai') return renderAI();
  if (view === 'announcements') return renderAnnouncements();
  if (view === 'gallery') return renderGallery();
  if (view === 'achievements') return renderAchievements();
  if (view === 'fees') return renderFees();
  if (view === 'attendance') return renderAttendance();
  if (view === 'messages') return renderMessages();
  if (view === 'calendar') return renderCalendar();
  if (view === 'children') return renderChildren();
  if (view === 'classes') return renderTeacherClasses();
  if (view === 'results-upload') return renderResultsUpload();
  if (view === 'cbt-manage') return renderCBTManage();
  if (view === 'students') return renderAdminStudents();
  if (view === 'admissions') return renderAdmissions();
  if (view === 'fees-admin') return renderFeesAdmin();
  if (view === 'results-admin') return renderResultsAdmin();
  if (view === 'settings') return renderSettings();

  return `<div class="text-center py-20 text-gray-400">Section under construction – demo placeholder</div>`;
}

function renderRoleDashboard(role) {
  if (role === 'student') {
    const s = state.user;
    return `
    <div>
      <h1 class="text-xl font-bold text-school-navy mb-1">Welcome back, ${s.name.split(' ')[0]} 👋</h1>
      <p class="text-sm text-gray-500 mb-6">${s.class} ${s.arm} • ${s.house} • ${s.session}</p>
      
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        ${[
          { label: 'Class Position', value: '4th', sub: 'of 42' },
          { label: 'Average', value: '81.3%', sub: 'First Term' },
          { label: 'Attendance', value: '96%', sub: 'This term' },
          { label: 'Pending Tasks', value: '3', sub: 'Assignments' }
        ].map(c => `
          <div class="stat-card p-4">
            <div class="text-2xl font-bold text-school-teal">${c.value}</div>
            <div class="text-xs font-medium text-gray-700 mt-1">${c.label}</div>
            <div class="text-[10px] text-gray-400">${c.sub}</div>
          </div>
        `).join('')}
      </div>

      <div class="grid md:grid-cols-2 gap-4">
        <div class="bg-white rounded-xl border p-4">
          <h3 class="font-semibold text-sm mb-3">Latest Announcements</h3>
          ${ANNOUNCEMENTS.slice(0, 3).map(a => `
            <div class="py-2 border-b last:border-0">
              <div class="text-sm font-medium">${a.title}</div>
              <div class="text-xs text-gray-400">${formatDate(a.date)} • ${a.category}</div>
            </div>
          `).join('')}
        </div>
        <div class="bg-white rounded-xl border p-4">
          <h3 class="font-semibold text-sm mb-3">Quick Actions</h3>
          <div class="grid grid-cols-2 gap-2">
            <button onclick="navigate('idcard')" class="p-3 rounded-lg bg-teal-50 text-teal-800 text-sm font-medium hover:bg-teal-100">Digital ID</button>
            <button onclick="navigate('results')" class="p-3 rounded-lg bg-blue-50 text-blue-800 text-sm font-medium hover:bg-blue-100">View Results</button>
            <button onclick="navigate('cbt')" class="p-3 rounded-lg bg-indigo-50 text-indigo-800 text-sm font-medium hover:bg-indigo-100">Take CBT</button>
            <button onclick="navigate('ai')" class="p-3 rounded-lg bg-purple-50 text-purple-800 text-sm font-medium hover:bg-purple-100">AI Tutor</button>
          </div>
        </div>
      </div>
    </div>`;
  }

  if (role === 'parent') {
    const child = state.activeChild || DEMO_USERS.student;
    return `
    <div>
      <h1 class="text-xl font-bold text-school-navy mb-1">Parent Dashboard</h1>
      <p class="text-sm text-gray-500 mb-4">Viewing: <strong>${child.name}</strong> (${child.class})</p>
      
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        ${[
          { label: 'Outstanding Fees', value: formatCurrency(SAMPLE_FEES.outstanding), sub: 'Due soon' },
          { label: 'Attendance', value: '96%', sub: 'This term' },
          { label: 'Average Score', value: '81.3%', sub: 'First Term' },
          { label: 'Messages', value: '2', sub: 'Unread' }
        ].map(c => `
          <div class="stat-card p-4">
            <div class="text-lg md:text-xl font-bold text-school-teal">${c.value}</div>
            <div class="text-xs font-medium text-gray-700 mt-1">${c.label}</div>
            <div class="text-[10px] text-gray-400">${c.sub}</div>
          </div>
        `).join('')}
      </div>

      <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4 text-sm">
        <strong>Payment reminder:</strong> Second Term fees outstanding. Due date: ${formatDate(SAMPLE_FEES.dueDate)}.
        <button onclick="navigate('fees')" class="ml-2 text-school-teal font-semibold underline">Pay / View</button>
      </div>

      <div class="grid md:grid-cols-2 gap-4">
        <div class="bg-white rounded-xl border p-4">
          <h3 class="font-semibold text-sm mb-3">Recent Results Snapshot</h3>
          ${SAMPLE_RESULTS.subjects.slice(0, 4).map(s => `
            <div class="flex justify-between text-sm py-1.5 border-b last:border-0">
              <span>${s.name}</span>
              <span class="font-semibold">${s.total} (${s.grade})</span>
            </div>
          `).join('')}
          <button onclick="navigate('results')" class="mt-3 text-school-teal text-sm font-medium">Full report card →</button>
        </div>
        <div class="bg-white rounded-xl border p-4">
          <h3 class="font-semibold text-sm mb-3">Quick Links</h3>
          <div class="space-y-2">
            <button onclick="navigate('fees')" class="w-full text-left p-2 rounded-lg hover:bg-gray-50 text-sm">💳 Fees & Receipts</button>
            <button onclick="navigate('messages')" class="w-full text-left p-2 rounded-lg hover:bg-gray-50 text-sm">💬 Message Teachers</button>
            <button onclick="navigate('calendar')" class="w-full text-left p-2 rounded-lg hover:bg-gray-50 text-sm">📆 School Calendar</button>
          </div>
        </div>
      </div>
    </div>`;
  }

  if (role === 'teacher') {
    return `
    <div>
      <h1 class="text-xl font-bold text-school-navy mb-1">Teacher Dashboard</h1>
      <p class="text-sm text-gray-500 mb-6">${state.user.subjects.join(', ')} • ${state.user.classes.length} classes</p>
      
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        ${[
          { label: 'My Classes', value: state.user.classes.length },
          { label: 'Students', value: '126' },
          { label: 'Pending Results', value: '2' },
          { label: 'Active CBT', value: '1' }
        ].map(c => `
          <div class="stat-card p-4 text-center">
            <div class="text-2xl font-bold text-school-teal">${c.value}</div>
            <div class="text-xs text-gray-600 mt-1">${c.label}</div>
          </div>
        `).join('')}
      </div>

      <div class="bg-white rounded-xl border p-4 mb-4">
        <h3 class="font-semibold text-sm mb-3">Assigned Classes</h3>
        ${state.user.classes.map(c => `
          <div class="flex justify-between items-center py-2 border-b last:border-0 text-sm">
            <span>${c}</span>
            <button onclick="navigate('attendance')" class="text-school-teal text-xs font-medium">Take Attendance</button>
          </div>
        `).join('')}
      </div>

      <div class="grid grid-cols-2 gap-3">
        <button onclick="navigate('results-upload')" class="p-4 rounded-xl bg-school-teal text-white font-semibold text-sm">Upload Results</button>
        <button onclick="navigate('cbt-manage')" class="p-4 rounded-xl bg-indigo-600 text-white font-semibold text-sm">Create CBT</button>
      </div>
    </div>`;
  }

  // Admin
  return `
  <div>
    <h1 class="text-xl font-bold text-school-navy mb-1">Administrator Dashboard</h1>
    <p class="text-sm text-gray-500 mb-6">School-wide overview • ${SCHOOL.name}</p>
    
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      ${[
        { label: 'Total Students', value: '487' },
        { label: 'Teachers', value: '34' },
        { label: 'Pending Admissions', value: '18' },
        { label: 'Outstanding Fees', value: '₦12.4M' },
        { label: "Today's Attendance", value: '94%' },
        { label: 'Upcoming Exams', value: '3' }
      ].map(c => `
        <div class="stat-card p-3 text-center">
          <div class="text-lg font-bold text-school-teal">${c.value}</div>
          <div class="text-[10px] text-gray-500 mt-0.5">${c.label}</div>
        </div>
      `).join('')}
    </div>

    <div class="grid md:grid-cols-2 gap-4">
      <div class="bg-white rounded-xl border p-4">
        <h3 class="font-semibold text-sm mb-3">Quick Management</h3>
        <div class="grid grid-cols-2 gap-2">
          <button onclick="navigate('students')" class="p-3 rounded-lg bg-teal-50 text-sm font-medium">Students</button>
          <button onclick="navigate('admissions')" class="p-3 rounded-lg bg-blue-50 text-sm font-medium">Admissions</button>
          <button onclick="navigate('fees-admin')" class="p-3 rounded-lg bg-amber-50 text-sm font-medium">Fees</button>
          <button onclick="navigate('results-admin')" class="p-3 rounded-lg bg-indigo-50 text-sm font-medium">Results</button>
        </div>
      </div>
      <div class="bg-white rounded-xl border p-4">
        <h3 class="font-semibold text-sm mb-3">Recent Activity</h3>
        <div class="text-sm text-gray-600 space-y-2">
          <div>• 3 new admission applications submitted</div>
          <div>• SSS 2 Science results uploaded</div>
          <div>• Inter-House Sports announcement published</div>
        </div>
      </div>
    </div>
  </div>`;
}

// ---------- Feature views (simplified but functional UI) ----------
function renderTimetable() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Class Timetable</h1>
    <p class="text-sm text-gray-500 mb-4">${state.user.class || 'SSS 2'} Science • Demo timetable (admin-editable in production)</p>
    ${Object.entries(TIMETABLE).map(([day, periods]) => `
      <div class="bg-white rounded-xl border mb-4 overflow-hidden">
        <div class="bg-school-teal text-white px-4 py-2 font-semibold text-sm">${day}</div>
        <div class="divide-y">
          ${periods.map(p => `
            <div class="px-4 py-2.5 flex justify-between text-sm">
              <div>
                <div class="font-medium">${p.subject}</div>
                <div class="text-xs text-gray-400">${p.teacher}</div>
              </div>
              <div class="text-gray-500 text-xs self-center">${p.time}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `).join('')}
  </div>`;
}

function renderResults() {
  const r = SAMPLE_RESULTS;
  return `
  <div>
    <div class="flex flex-wrap justify-between items-start gap-2 mb-4">
      <div>
        <h1 class="text-xl font-bold">Report Card</h1>
        <p class="text-sm text-gray-500">${r.term} • ${r.session}</p>
      </div>
      <button onclick="window.print()" class="no-print text-sm bg-school-teal text-white px-4 py-2 rounded-lg">Download / Print</button>
    </div>
    
    <div class="bg-white rounded-xl border overflow-hidden mb-4">
      <table class="w-full text-sm">
        <thead class="bg-gray-50 text-left">
          <tr>
            <th class="px-3 py-2">Subject</th>
            <th class="px-3 py-2 text-center">CA</th>
            <th class="px-3 py-2 text-center">Exam</th>
            <th class="px-3 py-2 text-center">Total</th>
            <th class="px-3 py-2 text-center">Grade</th>
          </tr>
        </thead>
        <tbody>
          ${r.subjects.map(s => `
            <tr class="border-t">
              <td class="px-3 py-2 font-medium">${s.name}</td>
              <td class="px-3 py-2 text-center">${s.ca}</td>
              <td class="px-3 py-2 text-center">${s.exam}</td>
              <td class="px-3 py-2 text-center font-semibold">${s.total}</td>
              <td class="px-3 py-2 text-center"><span class="bg-teal-100 text-teal-800 px-2 py-0.5 rounded text-xs font-bold">${s.grade}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>

    <div class="grid sm:grid-cols-3 gap-3 mb-4">
      <div class="stat-card p-3 text-center"><div class="text-xl font-bold text-school-teal">${r.average}%</div><div class="text-xs">Average</div></div>
      <div class="stat-card p-3 text-center"><div class="text-xl font-bold text-school-teal">${r.classPosition}</div><div class="text-xs">Class Position</div></div>
      <div class="stat-card p-3 text-center"><div class="text-xl font-bold text-school-teal">${r.subjects.length}</div><div class="text-xs">Subjects</div></div>
    </div>

    <div class="bg-white rounded-xl border p-4 space-y-3 text-sm">
      <div><strong>Teacher’s Comment:</strong> ${r.teacherComment}</div>
      <div><strong>Principal’s Comment:</strong> ${r.principalComment}</div>
    </div>
  </div>`;
}

function renderIdCard() {
  const s = state.user.role === 'parent' ? (state.activeChild || DEMO_USERS.student) : state.user;
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Digital Student ID</h1>
    <div class="id-card text-white p-6 max-w-sm mx-auto relative overflow-hidden">
      <div class="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
      <div class="flex items-start justify-between mb-4">
        <img src="${SCHOOL.logo}" alt="Logo" class="h-10 bg-white rounded p-0.5" />
        <div class="text-right text-[10px] opacity-80">2025/2026</div>
      </div>
      <div class="flex gap-4 items-center mb-4">
        <div class="w-20 h-20 rounded-xl bg-white/20 flex items-center justify-center text-3xl">👨‍🎓</div>
        <div>
          <div class="font-bold text-lg leading-tight">${s.name}</div>
          <div class="text-sm opacity-90">${s.id}</div>
          <div class="text-xs opacity-75 mt-1">${s.class} ${s.arm || ''}</div>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-2 text-xs mb-4">
        <div><span class="opacity-70">House</span><br><strong>${s.house}</strong></div>
        <div><span class="opacity-70">Session</span><br><strong>${s.session}</strong></div>
      </div>
      <div class="bg-white rounded-lg p-3 flex items-center justify-center">
        <div class="w-24 h-24 bg-gray-800 flex items-center justify-center text-white text-[10px] text-center leading-tight p-1">
          QR CODE<br/>${s.id}
        </div>
      </div>
      <div class="text-center text-[10px] mt-3 opacity-70">${SCHOOL.name} • Official Digital ID</div>
    </div>
    <p class="text-center text-xs text-gray-400 mt-4">QR code is a visual placeholder. Production version generates a secure, scannable QR.</p>
  </div>`;
}

function renderAssignments() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Assignments</h1>
    <div class="space-y-3">
      ${[
        { title: 'Mathematics – Quadratic Equations', subject: 'Mathematics', due: '2026-01-25', status: 'Pending' },
        { title: 'Physics Practical Report', subject: 'Physics', due: '2026-01-22', status: 'Submitted' },
        { title: 'English Essay – My Role Model', subject: 'English', due: '2026-01-28', status: 'Pending' }
      ].map(a => `
        <div class="bg-white rounded-xl border p-4 flex justify-between items-start">
          <div>
            <div class="font-medium">${a.title}</div>
            <div class="text-xs text-gray-400 mt-1">${a.subject} • Due ${formatDate(a.due)}</div>
          </div>
          <span class="text-xs px-2 py-1 rounded-full ${a.status === 'Pending' ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}">${a.status}</span>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderCBT() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">CBT Examination Centre</h1>
    <div class="bg-white rounded-xl border p-6 text-center">
      <div class="text-4xl mb-3">💻</div>
      <h2 class="font-bold text-lg mb-2">Online Examinations</h2>
      <p class="text-sm text-gray-500 mb-6 max-w-md mx-auto">Take computer-based tests with timer, auto-save, automatic marking and instant feedback. Teachers create and manage exams from their dashboard.</p>
      <div class="space-y-3 max-w-sm mx-auto">
        <div class="border rounded-lg p-3 text-left text-sm">
          <div class="font-medium">Mathematics – Mid-Term Test</div>
          <div class="text-xs text-gray-400">40 questions • 45 minutes • Available</div>
          <button class="mt-2 text-school-teal text-xs font-semibold" onclick="toast('CBT engine is a prototype UI. Full timed exam with auto-marking requires backend integration.')">Start Exam</button>
        </div>
        <div class="border rounded-lg p-3 text-left text-sm opacity-60">
          <div class="font-medium">Physics – Practice Quiz</div>
          <div class="text-xs text-gray-400">Completed • Score: 78%</div>
        </div>
      </div>
    </div>
  </div>`;
}

function renderLearning() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Digital Learning Centre</h1>
    <p class="text-sm text-gray-500 mb-4">Resources organised by Class → Subject → Topic</p>
    <div class="grid sm:grid-cols-2 gap-3">
      ${['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Islamic Studies'].map(sub => `
        <button class="bg-white border rounded-xl p-4 text-left hover:border-school-teal transition">
          <div class="font-semibold">${sub}</div>
          <div class="text-xs text-gray-400 mt-1">Notes • Videos • Past Questions • Quizzes</div>
        </button>
      `).join('')}
    </div>
  </div>`;
}

function renderAI() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">AI Study Assistant</h1>
    <div class="bg-white rounded-xl border p-4 mb-4">
      <p class="text-sm text-gray-600 mb-4">Ask questions about any school subject. Examples: “Explain photosynthesis for JSS2”, “Give me 10 algebra questions”, “Quiz me on Biology”.</p>
      <div class="flex gap-2">
        <input id="ai-input" type="text" placeholder="Type your question..." class="flex-1 border rounded-lg px-3 py-2 text-sm" />
        <button onclick="const q=$('#ai-input').value; if(q){toast('AI response would appear here. In production this calls a secure backend API (keys never exposed on frontend).');}" class="bg-school-teal text-white px-4 py-2 rounded-lg text-sm font-medium">Ask</button>
      </div>
    </div>
    <div class="text-xs text-gray-400 bg-gray-50 rounded-lg p-3">
      <strong>Security note:</strong> API keys must remain on the server. The frontend only sends the student question and receives the response. Guided step-by-step mode is planned for the full version.
    </div>
  </div>`;
}

function renderAnnouncements() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Announcements</h1>
    <div class="space-y-3">
      ${ANNOUNCEMENTS.map(a => `
        <div class="bg-white rounded-xl border p-4">
          <div class="flex justify-between items-start gap-2">
            <h3 class="font-semibold text-sm">${a.title}</h3>
            <span class="text-[10px] bg-gray-100 px-2 py-0.5 rounded shrink-0">${a.category}</span>
          </div>
          <p class="text-sm text-gray-600 mt-2">${a.excerpt}</p>
          <div class="text-xs text-gray-400 mt-2">${formatDate(a.date)}</div>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderGallery() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">School Gallery</h1>
    <p class="text-sm text-gray-500 mb-4">Events, sports, prize-giving, cultural activities and more. Images sourced from the official website where available.</p>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
      ${[
        { title: 'School Compound', src: 'https://anwarulislammodelcollege.com/wp-content/uploads/2024/04/School-Compound.jpeg' },
        { title: 'Front of General Hall', src: 'https://anwarulislammodelcollege.com/wp-content/uploads/2024/04/Front-of-General-Hall.jpeg' },
        { title: 'Science Lab', src: 'https://anwarulislammodelcollege.com/wp-content/uploads/2024/05/Student-in-the-Lab-1.jpg' },
        { title: 'Football Team', src: 'https://anwarulislammodelcollege.com/wp-content/uploads/2024/09/School-Football-Team.jpg' },
        { title: 'St Olave UK Twinning', src: 'https://anwarulislammodelcollege.com/wp-content/uploads/2024/09/ST-OLAVE-UK-TWINNING-PROGRAMS.jpg' }
      ].map(g => `
        <div class="rounded-xl overflow-hidden border bg-white">
          <img src="${g.src}" alt="${g.title}" class="w-full h-32 object-cover" loading="lazy" onerror="this.src='assets/logo.png'" />
          <div class="p-2 text-xs font-medium text-center">${g.title}</div>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderAchievements() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Achievements & Badges</h1>
    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
      ${BADGES.map(b => `
        <div class="bg-white rounded-xl border p-4 text-center ${b.earned ? '' : 'opacity-40'}">
          <div class="text-3xl mb-2">${b.icon}</div>
          <div class="text-sm font-medium">${b.name}</div>
          <div class="text-[10px] mt-1 ${b.earned ? 'text-green-600' : 'text-gray-400'}">${b.earned ? 'Earned' : 'Locked'}</div>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderFees() {
  const f = SAMPLE_FEES;
  const total = f.items.reduce((s, i) => s + i.amount, 0);
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Fees & Payments</h1>
    <div class="bg-white rounded-xl border p-4 mb-4">
      <div class="text-sm text-gray-500 mb-2">${f.term} • ${f.session}</div>
      <div class="space-y-2">
        ${f.items.map(i => `
          <div class="flex justify-between text-sm">
            <span>${i.name}</span>
            <span class="font-medium">${formatCurrency(i.amount)}</span>
          </div>
        `).join('')}
        <div class="border-t pt-2 flex justify-between font-bold">
          <span>Total</span>
          <span>${formatCurrency(total)}</span>
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 gap-3 mb-4">
      <div class="stat-card p-3 text-center">
        <div class="text-lg font-bold text-green-600">${formatCurrency(f.paid)}</div>
        <div class="text-xs">Paid</div>
      </div>
      <div class="stat-card p-3 text-center">
        <div class="text-lg font-bold text-amber-600">${formatCurrency(f.outstanding)}</div>
        <div class="text-xs">Outstanding</div>
      </div>
    </div>
    <p class="text-xs text-gray-400 mb-3">Due date: ${formatDate(f.dueDate)}</p>
    <button onclick="toast('Payment gateway integration (e.g. Paystack / Flutterwave) is prepared in architecture but not live in this prototype.', 'info')" 
      class="w-full py-3 bg-school-teal text-white rounded-xl font-semibold">Pay Outstanding Balance</button>
    <button class="w-full mt-2 py-2 text-sm text-school-teal font-medium">Download Receipts</button>
  </div>`;
}

function renderAttendance() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Attendance</h1>
    <div class="bg-white rounded-xl border p-4 mb-4 text-center">
      <div class="text-3xl font-bold text-school-teal">96%</div>
      <div class="text-sm text-gray-500">Overall this term</div>
    </div>
    <div class="bg-white rounded-xl border overflow-hidden">
      <div class="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-500">Recent records (demo)</div>
      ${['Mon 12 Jan – Present', 'Tue 13 Jan – Present', 'Wed 14 Jan – Present', 'Thu 15 Jan – Absent (Sick)', 'Fri 16 Jan – Present'].map(r => `
        <div class="px-4 py-2.5 text-sm border-t flex justify-between">
          <span>${r.split(' – ')[0]}</span>
          <span class="${r.includes('Absent') ? 'text-red-600' : 'text-green-600'} font-medium">${r.split(' – ')[1]}</span>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderMessages() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Parent–Teacher Messages</h1>
    <p class="text-sm text-gray-500 mb-4">Secure in-app messaging. Private phone numbers are never exposed.</p>
    <div class="bg-white rounded-xl border p-4 space-y-3">
      <div class="border rounded-lg p-3">
        <div class="text-xs text-gray-400">Mr. Olumide Akinwale (Mathematics)</div>
        <div class="text-sm mt-1">Please encourage Ibrahim to complete the additional practice questions before the next test.</div>
        <div class="text-[10px] text-gray-400 mt-2">2 days ago</div>
      </div>
      <div class="border rounded-lg p-3 bg-teal-50/50">
        <div class="text-xs text-gray-400">You</div>
        <div class="text-sm mt-1">Thank you. We will ensure he practices this weekend.</div>
      </div>
    </div>
    <div class="mt-4 flex gap-2">
      <input type="text" placeholder="Type a message..." class="flex-1 border rounded-lg px-3 py-2 text-sm" />
      <button class="bg-school-teal text-white px-4 rounded-lg text-sm" onclick="toast('Message sent (demo)')">Send</button>
    </div>
  </div>`;
}

function renderCalendar() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">School Calendar</h1>
    <div class="space-y-2">
      ${CALENDAR.map(e => `
        <div class="bg-white rounded-xl border p-3 flex gap-3 items-center">
          <div class="w-12 text-center shrink-0">
            <div class="text-xs text-gray-400">${new Date(e.date).toLocaleString('en', {month:'short'})}</div>
            <div class="text-lg font-bold text-school-teal">${new Date(e.date).getDate()}</div>
          </div>
          <div>
            <div class="font-medium text-sm">${e.title}</div>
            <div class="text-xs text-gray-400 capitalize">${e.type}</div>
          </div>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderChildren() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">My Children</h1>
    <div class="bg-white rounded-xl border p-4 flex items-center gap-4">
      <div class="w-14 h-14 rounded-full bg-teal-100 flex items-center justify-center text-2xl">👨‍🎓</div>
      <div class="flex-1">
        <div class="font-semibold">${DEMO_USERS.student.name}</div>
        <div class="text-sm text-gray-500">${DEMO_USERS.student.class} ${DEMO_USERS.student.arm} • ${DEMO_USERS.student.id}</div>
      </div>
      <button class="text-school-teal text-sm font-medium" onclick="state.activeChild=DEMO_USERS.student;navigate('dashboard')">View</button>
    </div>
    <p class="text-xs text-gray-400 mt-4">Parents can link multiple children. Switch between them from the dashboard.</p>
  </div>`;
}

function renderTeacherClasses() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">My Classes</h1>
    ${state.user.classes.map(c => `
      <div class="bg-white rounded-xl border p-4 mb-3 flex justify-between items-center">
        <div>
          <div class="font-semibold">${c}</div>
          <div class="text-xs text-gray-400">~42 students</div>
        </div>
        <button onclick="navigate('attendance')" class="text-sm text-school-teal font-medium">Attendance</button>
      </div>
    `).join('')}
  </div>`;
}

function renderResultsUpload() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Upload Results</h1>
    <div class="bg-white rounded-xl border p-6">
      <p class="text-sm text-gray-600 mb-4">Select class and subject, then enter CA and Examination scores. Production version supports bulk CSV upload and validation.</p>
      <div class="space-y-3">
        <select class="w-full border rounded-lg px-3 py-2 text-sm"><option>SSS 2 Science</option></select>
        <select class="w-full border rounded-lg px-3 py-2 text-sm"><option>Mathematics</option></select>
        <button class="w-full py-3 bg-school-teal text-white rounded-xl font-semibold" onclick="toast('Results upload form ready for backend integration')">Continue to Score Entry</button>
      </div>
    </div>
  </div>`;
}

function renderCBTManage() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Manage CBT Examinations</h1>
    <button class="mb-4 bg-school-teal text-white px-4 py-2 rounded-lg text-sm font-medium" onclick="toast('Exam creator UI – full question bank & timer settings require backend')">+ Create New Exam</button>
    <div class="bg-white rounded-xl border p-4 text-sm text-gray-600">
      Existing exams appear here. Teachers can set duration, number of questions, shuffle options, and release results.
    </div>
  </div>`;
}

function renderAdminStudents() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Students</h1>
    <div class="bg-white rounded-xl border overflow-hidden">
      <div class="px-4 py-3 bg-gray-50 text-xs font-semibold flex justify-between">
        <span>Name</span><span>Class</span><span>ID</span>
      </div>
      ${[DEMO_USERS.student, {name:'Yusuf Ahmed', class:'SSS 1 Science', id:'STU-2024-0087'}, {name:'Chinedu Okeke', class:'JSS 3', id:'STU-2025-0211'}].map(s => `
        <div class="px-4 py-2.5 text-sm border-t flex justify-between">
          <span class="font-medium">${s.name}</span>
          <span class="text-gray-500">${s.class}</span>
          <span class="text-xs text-gray-400">${s.id}</span>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function renderAdmissions() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Admissions</h1>
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
      ${['Submitted', 'Under Review', 'Accepted', 'Registration Complete'].map((s,i) => `
        <div class="stat-card p-3 text-center">
          <div class="text-xl font-bold text-school-teal">${[12, 8, 5, 3][i]}</div>
          <div class="text-[10px] text-gray-500">${s}</div>
        </div>
      `).join('')}
    </div>
    <div class="bg-white rounded-xl border p-4 text-sm text-gray-600">
      Full online admission flow includes: applicant account, biodata, parent details, class selection, passport & document upload, previous school info, emergency contacts, application tracking, status notifications and admission letter generation.
    </div>
  </div>`;
}

function renderFeesAdmin() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Fees Management</h1>
    <div class="stat-card p-4 mb-4 text-center">
      <div class="text-2xl font-bold text-amber-600">₦12.4M</div>
      <div class="text-sm text-gray-500">Total Outstanding (demo figure)</div>
    </div>
    <p class="text-sm text-gray-600">Architecture is ready for integration with legitimate Nigerian payment providers (Paystack, Flutterwave, etc.). Fee structures, invoices, receipts and reminders are managed here.</p>
  </div>`;
}

function renderResultsAdmin() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">Results Centre (Admin)</h1>
    <p class="text-sm text-gray-600 mb-4">Approve, publish and manage term results across all classes. Teachers upload; administrators control visibility to students and parents.</p>
    <button class="bg-school-teal text-white px-4 py-2 rounded-lg text-sm" onclick="toast('Publish controls ready for backend')">Publish First Term Results</button>
  </div>`;
}

function renderSettings() {
  return `
  <div>
    <h1 class="text-xl font-bold mb-4">School Settings</h1>
    <div class="bg-white rounded-xl border p-4 space-y-3 text-sm">
      <div class="flex justify-between"><span>School Name</span><span class="font-medium">${SCHOOL.name}</span></div>
      <div class="flex justify-between"><span>Current Session</span><span class="font-medium">2025/2026</span></div>
      <div class="flex justify-between"><span>Current Term</span><span class="font-medium">Second Term</span></div>
      <div class="flex justify-between"><span>Principal</span><span class="font-medium">${SCHOOL.principal}</span></div>
      <div class="pt-3 border-t text-xs text-gray-400">All school facts are pulled from the official website. Additional fields (houses, exact fee amounts, detailed timetable) are administrator-editable placeholders.</div>
    </div>
  </div>`;
}

function bindEvents() {
  // Modal close on backdrop
  const modal = document.getElementById('login-modal');
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.add('hidden');
    });
  }
}

// Boot
document.addEventListener('DOMContentLoaded', () => {
  render();
});
