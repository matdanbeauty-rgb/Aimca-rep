/**
 * Anwar-Ul Islam Model College – Official & Demo Data
 * All school facts are taken from https://anwarulislammodelcollege.com/
 * Demo student/parent/teacher data is fictional for prototype purposes.
 */

const SCHOOL = {
  name: "Anwar-Ul Islam Model College",
  shortName: "AIMC",
  motto: "Learn • Grow • Excel",
  tagline: "The first secondary school solely founded by Muslims in Nigeria and along the Coast of West Africa",
  address: "1, Oniwaya Road, Dopemu Agege, Lagos",
  phone: "+234 803 385 6059",
  email: "info@anwarulislammodelcollege.com",
  website: "https://anwarulislammodelcollege.com/",
  logo: "assets/logo.png",
  vision: "To produce excellent and decent Men who will excel globally and contribute to the society with good mannerism.",
  mission: "To provide qualitative value in Islamic and Western Education which brings the best potential in the personality and academic life of Male Students.",
  principal: "Mr Soyebo Waheed Olusola",
  founded: 1948,
  location: "Agege, Lagos, Nigeria",
  type: "Boys Secondary School",
  historyShort: "Anwar-Ul Islam Model College, formerly known as Saka Tinubu Memorial Ahmadiyya High School, Olushi, Lagos, holds the distinction of being the first secondary school solely founded by Muslims in Nigeria and along the Coast of West Africa. Established in 1948 by visionary Muslim leaders, including Late Alhaji Jubril Martins, the college has a rich history of dedication to both academic excellence and Islamic principles. Over the years, it has evolved and grown, moving to its current location in Agege, Lagos, in 1956.",
  historyFull: `The College was initially known as Saka Tinubu Memorial Ahmadiyya High School, Olushi, Lagos. Our college is the first Secondary School solely founded by Muslims in Nigeria and even along the Coast of West Africa.

Eighty-nine years before 1948, the Church Missionary Society had established a Grammar School for secondary school age students along what is today known as Broad Street, Lagos. It was the first Secondary School in Nigeria solely founded by Christians. Between then and 1948, six colleges (all for boys) were founded: Igbobi College, King’s College, Baptist Academy, St. Gregory’s College, Methodist Boys’ High School and Eko Boys’ High School.

The muslim elders who knew the value of modern Education coupled with Islamic precepts felt the need for such a secondary school for their own Muslim children. The founding fathers included Late Alhaji Jubril Martins, Late Alhaji B. D. Oshodi, Late Alhaji N. B. Kenku, Late Alhaji K. D. Oshodi, Late Alhaji B. A. Fanimokun, Late Alhaji A. S. E. Agbabiaka, Late Chief Imam Ashafa Tijani, Late Imam Ismail (Epetedo), Late Alhaji R. A. Allison among others.

On Monday, 5th April, 1948, the doors of Saka Tinubu Memorial Ahmadiyya High School at Olushi Street, Lagos were thrown open to students. In January 1956, there was a change of name from Saka Tinubu Memorial High School to Ahmadiyya College, as well as movement of the College to the present site in Agege. In 1976, the Proprietors of the College changed the name of the school to Anwar-ul Islam College, Agege.

In 2001, the then Governor of Lagos State, His Excellency, Asiwaju Bola Ahmed Tinubu returned the school to its proprietors. The college continues to excel in academics, sports and character formation.`,
  facilities: [
    "Well equipped science laboratories",
    "Attractive, neat and serene learning environment",
    "Hostel accommodation for boarding house students",
    "Seasoned, competent, qualified and well experienced academic and non academic staff",
    "Top range health facility with well equipped college clinic",
    "Well stocked E-library with internet connection",
    "Scholarships for indigent and brilliant students",
    "24/7 solar within the school premises – No power outage and no pollution",
    "Effective Quranic and Arabic studies with French curriculum at Junior classes",
    "Excellent moral and religious value",
    "Adequate and standard extra curricular activities for students",
    "Maximum security guaranteed",
    "School Sport Arena"
  ],
  board: [
    { name: "Alhaji Hameed A. Ajani", role: "Chairman" },
    { name: "Alhaji Adeosun A.A", role: "Vice Chairman" },
    { name: "Alhaji Abdulrahman Alarape Snr.", role: "ACAOSA" },
    { name: "Hon. Lawal Pedro SAN", role: "ACAOSA" },
    { name: "Mr Adedokun Adewumi", role: "PTA Chairman" },
    { name: "Alhaja Bolanle Dosumu", role: "Member" },
    { name: "Mr Soyebo Waheed Olusola", role: "Principal" }
  ],
  houses: ["Red House", "Blue House", "Green House", "Yellow House"], // Placeholder – admin editable
  sports: ["Football", "Athletics", "Basketball", "Volleyball", "Table Tennis", "Inter-House Sports"],
  colours: { primary: "#0d9488", secondary: "#d4a017", accent: "#1e3a5f" }
};

// Demo users (fictional for prototype)
const DEMO_USERS = {
  student: {
    id: "STU-2024-0142",
    name: "Adebayo Ibrahim",
    email: "adebayo.ibrahim@student.aimc.edu.ng",
    role: "student",
    class: "SSS 2",
    arm: "Science",
    house: "Blue House",
    session: "2025/2026",
    photo: null,
    parentId: "PAR-001"
  },
  parent: {
    id: "PAR-001",
    name: "Mrs. Fatima Adebayo",
    email: "fatima.adebayo@email.com",
    role: "parent",
    children: ["STU-2024-0142"]
  },
  teacher: {
    id: "TCH-018",
    name: "Mr. Olumide Akinwale",
    email: "o.akinwale@aimc.edu.ng",
    role: "teacher",
    subjects: ["Mathematics", "Further Mathematics"],
    classes: ["SSS 1 Science", "SSS 2 Science", "SSS 3 Science"]
  },
  admin: {
    id: "ADM-001",
    name: "Admin Portal",
    email: "admin@anwarulislammodelcollege.com",
    role: "admin"
  }
};

// Sample announcements
const ANNOUNCEMENTS = [
  {
    id: 1,
    title: "2025 Inter-House Sports Competition – Champions Emerge",
    date: "2025-03-16",
    category: "Sports",
    excerpt: "Champions emerge as Anwar-Ul Islam Model College, Agege hosts the 2025 Inter-House Sports Competition."
  },
  {
    id: 2,
    title: "Second Term Examination Timetable Released",
    date: "2026-01-20",
    category: "Academic",
    excerpt: "The second term examination timetable has been published. Students are advised to check the portal."
  },
  {
    id: 3,
    title: "PTA Meeting – Notice",
    date: "2026-02-05",
    category: "PTA",
    excerpt: "All parents and guardians are invited to the general PTA meeting scheduled for Saturday."
  }
];

// Sample timetable (placeholder – admin editable)
const TIMETABLE = {
  "Monday": [
    { time: "08:00 – 08:40", subject: "Mathematics", teacher: "Mr. Akinwale" },
    { time: "08:40 – 09:20", subject: "English Language", teacher: "Mrs. Bello" },
    { time: "09:20 – 10:00", subject: "Physics", teacher: "Mr. Okoro" },
    { time: "10:20 – 11:00", subject: "Chemistry", teacher: "Mrs. Adeyemi" },
    { time: "11:00 – 11:40", subject: "Biology", teacher: "Mr. Hassan" }
  ],
  "Tuesday": [
    { time: "08:00 – 08:40", subject: "Further Mathematics", teacher: "Mr. Akinwale" },
    { time: "08:40 – 09:20", subject: "Economics", teacher: "Mrs. Yusuf" },
    { time: "09:20 – 10:00", subject: "Islamic Studies", teacher: "Mallam Ibrahim" },
    { time: "10:20 – 11:00", subject: "Computer Science", teacher: "Mr. Ojo" },
    { time: "11:00 – 11:40", subject: "Literature", teacher: "Mrs. Bello" }
  ]
};

// Sample results
const SAMPLE_RESULTS = {
  term: "First Term",
  session: "2025/2026",
  subjects: [
    { name: "Mathematics", ca: 28, exam: 55, total: 83, grade: "A", position: 3 },
    { name: "English Language", ca: 25, exam: 48, total: 73, grade: "B", position: 7 },
    { name: "Physics", ca: 30, exam: 52, total: 82, grade: "A", position: 2 },
    { name: "Chemistry", ca: 27, exam: 50, total: 77, grade: "B", position: 5 },
    { name: "Biology", ca: 29, exam: 54, total: 83, grade: "A", position: 4 },
    { name: "Islamic Studies", ca: 32, exam: 58, total: 90, grade: "A", position: 1 }
  ],
  average: 81.3,
  classPosition: 4,
  teacherComment: "Adebayo is a diligent student who shows excellent understanding of scientific concepts. He should maintain consistency.",
  principalComment: "Well done. Continue to strive for excellence."
};

// Sample fees
const SAMPLE_FEES = {
  session: "2025/2026",
  term: "Second Term",
  items: [
    { name: "Tuition", amount: 85000 },
    { name: "Boarding (optional)", amount: 120000 },
    { name: "Development Levy", amount: 15000 },
    { name: "ICT & Library", amount: 10000 },
    { name: "Sports & Clubs", amount: 5000 }
  ],
  paid: 85000,
  outstanding: 150000,
  dueDate: "2026-02-28"
};

// Achievements / badges
const BADGES = [
  { id: "academic", name: "Academic Excellence", icon: "🏆", earned: true },
  { id: "attendance", name: "Perfect Attendance", icon: "⭐", earned: false },
  { id: "quiz", name: "Quiz Master", icon: "🧠", earned: true },
  { id: "reading", name: "Reading Champion", icon: "📚", earned: false },
  { id: "improvement", name: "Outstanding Improvement", icon: "🎯", earned: false },
  { id: "character", name: "Good Character", icon: "🤝", earned: true }
];

// Calendar events (mix of real + placeholder)
const CALENDAR = [
  { date: "2025-03-16", title: "Inter-House Sports Competition", type: "sports" },
  { date: "2026-01-20", title: "Second Term Exams Begin", type: "exam" },
  { date: "2026-02-05", title: "PTA General Meeting", type: "pta" },
  { date: "2026-03-15", title: "Cultural Day", type: "event" },
  { date: "2026-04-05", title: "Founders' Day / Anniversary", type: "event" }
];
